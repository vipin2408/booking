//
//  ViewController.swift
//  Nagelli_TravelBooking
//
//  Created by bumchikwawa on 4/2/24.
//

import UIKit

class BookingViewController: UIViewController {
    
    var TrName = ""
    var numOfTr = 0
    var cabinType = ""
    var res = ""
    var price = 0.0
    var imageDescription = ""
    
    
    
    @IBOutlet weak var travellerNameOl: UITextField!
    
    
    @IBOutlet weak var noOfTravellersOl: UITextField!
    
    
    @IBOutlet weak var cabinTypeOl: UITextField!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        
    }

    @IBAction func bookNowButton(_ sender: Any) {
        if((cabinTypeOl.text?.lowercased())! == "economy"){
                    
                    
                    TrName = (travellerNameOl.text!)
                    numOfTr = Int((noOfTravellersOl.text!)) ?? 0
                    
                    
                    price = Double(numOfTr * 125);
                    imageDescription = "economy"
                    
                    
                    
                }
                else if((cabinTypeOl.text?.lowercased())! == "luxury"){
                    TrName = (travellerNameOl.text!)
                    numOfTr = Int((noOfTravellersOl.text!)) ?? 0
                    
                    cabinType = (cabinTypeOl.text!)
                    price = Double(numOfTr * 200);
                    imageDescription = "luxury"
                    
                }
                
                else{
                    imageDescription = "NoBus"
                    
                }
            }
            override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
                if(segue.identifier == "resultSegue"){
                    let destination = segue.destination as! ResultViewController
                    destination.TrName = TrName
                    destination.numOfTr = numOfTr
                    destination.cabinType = cabinType
                    destination.price = price
                    destination.imageDescription = imageDescription
                    
                    
                }
                
            }
            
            
        
    }
    


