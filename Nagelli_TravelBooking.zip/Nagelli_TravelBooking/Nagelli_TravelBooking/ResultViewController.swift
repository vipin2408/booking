//
//  ResultViewController.swift
//  Nagelli_TravelBooking
//
//  Created by bumchikwawa on 4/2/24.
//

import UIKit

class ResultViewController: UIViewController {
    
    
    
 
   var TrName = ""
    var numOfTr = 0
    var cabinType = ""
    var res = ""
    var price = 0.0
    var imageDescription = ""
    
    
    
    
    
    @IBOutlet weak var imageOl: UIImageView!
    
    
    @IBOutlet weak var resultOl: UILabel!
    
    
    @IBOutlet weak var travellerNameOl: UILabel!
    
    
    @IBOutlet weak var noOfTravellersOl: UILabel!
    
    
    @IBOutlet weak var cabinTypeOl: UILabel!
    
    
    @IBOutlet weak var totalCostOl: UILabel!
    
    
    
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        var cc = cabinType.lowercased()
        
        if( cc == "economy" || cc == "luxury" ){
            
        
        imageOl.image = UIImage(named: imageDescription)
        resultOl.text = "Hello \(TrName) ,Your booking is Confirmed."
        travellerNameOl.text = "Name: \(TrName)"
        noOfTravellersOl.text = "Number of Travellers :\(numOfTr)"
        cabinTypeOl.text = "cabinType : \(cabinType)"
        totalCostOl.text = "Total : \(price)"
      }
        else{
            imageOl.image = UIImage(named: imageDescription)
            resultOl.text = "There is no selected class. Please choose a valid class"
            travellerNameOl.isHidden = true
            noOfTravellersOl.isHidden = true
            cabinTypeOl.isHidden = true
            totalCostOl.isHidden = true
            
        }
        
        
    }
    

    
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
